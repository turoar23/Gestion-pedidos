const express = require('express')
const Router = express.Router();

const riderController = require('../controllers/riderController');

Router.get('/getRiders', riderController.getRiders);

Router.post('/getRiderByCode', riderController.getRiderByCode);

Router.post('/newRider', riderController.postNewRider);

Router.get('/getActiveRiderOrders/:riderId', riderController.getActiveOrders);

Router.get('/getRiderOrders/:riderId', riderController.getOrders);

Router.get('/getResumenByRider/:riderId/:date/', riderController.getOrdersByRiderByDates);

Router.post('/toggleRiderStatus',riderController.toggleStatusRider);

module.exports = Router;